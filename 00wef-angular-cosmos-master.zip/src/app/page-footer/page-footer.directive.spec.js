/**
* angular-starter-kit
*
* @author Andrea SonnY <andreasonny83@gmail.com>
* @copyright 2016 Andrea SonnY <andreasonny83@gmail.com>
*
* This code may only be used under the MIT style license.
*
* @license MIT  https://andreasonny.mit-license.org/@2016/
*/
'use strict';

describe('test page-footer directive', function() {
  beforeEach(module('app'));

  it('should render the page-footer module', function() {
    expect('true').toBe('true');
  });
});
