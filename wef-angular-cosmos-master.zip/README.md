# WEF SGD TOOL

## 1. cd into angular-starter-kit
## 2. npm install
## 3. npm start
