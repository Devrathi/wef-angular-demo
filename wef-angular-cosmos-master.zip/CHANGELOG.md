# Angular Starter Kit Changelog

## 1.4.0 - 2017.07.03

* AngularJS upgraded to v1.6.4
* Angular Material upgraded to v1.1.4
* Adding support for Yarn
* Bower included in npm dev dependencies
* Documentation updated

## 1.3.1 - 2016.07.10

* End-to-end tests introduced with Protractor
* Demo e2e scenario
* Travis task updated
* Gulp tasks improved and refactored
* Karma-coverage and Istanbul introduced
* Documentation updated

## 1.2.1 - 2016.07.09

* Favicon bug fixed
* Repository logo
* Documentation updated

## 1.2.0 - 2016.07.08

* Replacing Material Design Lite with Angular Material
* Better Gulp
* Removing JSHint in favour of ESLint
* Karma improved for Unit testing
* General restyling and better Web Application support

## 1.0.1 - 2015.12.28

* Twitter Bootstrap and JQuery removed and implemented Bourbon with Neat
* Support for web app
* File structure improved according to the JohnPapa styleguide
* Icons
* Robots.txt
* Manifest.webapp for web app support
* Gulp file updated
* Support for Google Analytics in index.html

## 1.0.0 - 2015.10.17

* Initial release
